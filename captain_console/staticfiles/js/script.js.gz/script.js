// src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD2m2yR2metYyz_erkHQVbs98JhZPC-fkc&callback=initMap";
//
// // Google maps dót
// function initMap(){
//     var home = {lat: 64.100730, lng: -21.898957};
//     var map = new google.maps.Map(
//         document.getElementById('map'), {zoom: 5, center: home});
//     var marker = new google.maps.Marker({position: home, map: map});
